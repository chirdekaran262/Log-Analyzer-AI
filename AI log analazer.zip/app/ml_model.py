import os
import joblib
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import Pipeline

MODEL_DIR = "model"
MODEL_PATH = os.path.join(MODEL_DIR, "advanced_model.pkl")


def train_model(sample_logs, max_features=200, svd_components=20, contamination=0.05):
    """Train and persist an unsupervised pipeline using TF-IDF -> SVD -> IsolationForest.

    sample_logs: list of dicts with a `message` key.
    """
    texts = [log["message"] for log in sample_logs if "message" in log]

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(max_features=max_features)),
        ("svd", TruncatedSVD(n_components=min(svd_components, max_features - 1))),
        ("isolation", IsolationForest(contamination=contamination, random_state=42))
    ])

    # Fit pipeline (accepts raw texts)
    pipeline.fit(texts)

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)


def load_model():
    if not os.path.exists(MODEL_PATH):
        return None
    try:
        return joblib.load(MODEL_PATH)
    except Exception:
        return None


def predict_anomaly(logs):
    model = load_model()

    if model is None:
        return {
            "prediction": "Model not trained",
            "anomaly_logs": 0,
            "avg_score": 0.0
        }

    texts = [log.get("message", "") for log in logs]

    try:
        predictions = model.predict(texts)
        scores = model.decision_function(texts)
    except Exception:
        return {
            "prediction": "Model error",
            "anomaly_logs": 0,
            "avg_score": 0.0
        }

    anomaly_count = int(np.sum(predictions == -1))
    overall = "Anomaly" if anomaly_count > len(logs) * 0.3 else "Normal"

    avg_score = float(np.mean(scores)) if len(scores) > 0 else 0.0

    return {
        "prediction": overall,
        "anomaly_logs": anomaly_count,
        "avg_score": avg_score
    }