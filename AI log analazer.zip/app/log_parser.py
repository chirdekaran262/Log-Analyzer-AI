def parse_log(file_path):
    logs = []
    with open(file_path, "r") as file:
        for line in file:
            parts = line.strip().split(" ", 3)
            if len(parts) >= 4:
                timestamp = parts[0] + " " + parts[1]
                level = parts[2]
                message = parts[3]
                logs.append({
                    "timestamp": timestamp,
                    "level": level,
                    "message": message
                })
    return logs