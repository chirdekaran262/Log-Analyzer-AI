from fastapi import FastAPI, UploadFile, File, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse

import shutil
import os

from app.log_parser import parse_log
from app.feature_extractor import extract_features
from app.rule_engine import rule_based_detection
from app.ml_model import predict_anomaly, load_model, train_model

app = FastAPI()
templates = Jinja2Templates(directory="templates")

UPLOAD_DIR = "logs"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.post("/analyze", response_class=HTMLResponse)
async def analyze_log(request: Request, file: UploadFile = File(...)):
    file_path = f"{UPLOAD_DIR}/{file.filename}"

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    logs = parse_log(file_path)
    features = extract_features(logs)
    rule_incidents = rule_based_detection(features)
    # If no trained model exists, train one on the uploaded logs (unsupervised)
    if load_model() is None and len(logs) > 0:
        try:
            train_model(logs)
        except Exception:
            pass

    ml_result = predict_anomaly(logs)

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "features": features,
        "rule_alerts": rule_incidents,
        "ml_result": ml_result
    })