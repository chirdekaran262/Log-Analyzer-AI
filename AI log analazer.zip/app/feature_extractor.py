import numpy as np

def extract_features(logs):
    error_count = 0
    warn_count = 0
    info_count = 0
    failed_login_count = 0

    timestamps = []

    for log in logs:
        level = log.get("level", "").upper()
        if level == "ERROR":
            error_count += 1
        elif level == "WARN":
            warn_count += 1
        elif level == "INFO":
            info_count += 1

        # case-insensitive failed login detection
        if "failed login" in log.get("message", "").lower():
            failed_login_count += 1

        timestamps.append(log.get("timestamp"))

    total_logs = len(logs)

    error_ratio = error_count / total_logs if total_logs > 0 else 0

    return {
        "error_count": error_count,
        "warn_count": warn_count,
        "info_count": info_count,
        "failed_login_count": failed_login_count,
        "total_logs": total_logs,
        "error_ratio": error_ratio
    }