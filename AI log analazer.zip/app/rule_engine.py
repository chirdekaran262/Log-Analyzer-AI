def rule_based_detection(features):
    incidents = []

    if features["error_count"] > 3:
        incidents.append("High error rate detected")

    if features["failed_login_count"] > 3:
        incidents.append("Multiple failed login attempts detected")

    return incidents